<?php
if(isset($_POST['email'])) {
	
	// CHANGE THE TWO LINES BELOW
	$email_to = "haidyl@gmail.com";
	
	$email_subject = "Azure HPC Contact Us Form";
	
	
	function died($error) {
		// your error code can go here
		echo '<span style="font-size:14px; font-weight:bold; color:red; font-family:calibri;">We are sorry..!, there is some error found with the form you submitted.</span><br /><br />';
		echo $error."<br /><br />";
		echo "Please enter valid data in each field. Thank You!<br /><br />";
		die();
	}
	
	// validation expected data exists
	if(!isset($_POST['name']) ||
		!isset($_POST['email']) ||
		!isset($_POST['phone']) ||
		!isset($_POST['company']) ||
		!isset($_POST['subject']) ||
		!isset($_POST['message'])) {
		died('<span style="font-size:14px; font-weight:bold; color:red; font-family:calibri;">We are sorry..!, there appears to be a problem with the form you submitted.</span>');		
	}
	
	$name = $_POST['name']; // required
	$email = $_POST['email']; // required
	$phone = $_POST['phone']; // not required
	$company = $_POST['company']; // not required
	$subject = $_POST['subject']; // required
	$message = $_POST['message']; // required
	
	$error_message = "";
	$email_exp = '/^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}$/';
  if(!preg_match($email_exp,$email)) {
  	$error_message .= '<b style="font-size:12px; color:black; font-family:calibri;">The Email Address you entered does not appear to be valid.</b><br />';
  }
	$string_exp = "/^[A-Za-z .'-]+$/";
  if(!preg_match($string_exp,$name)) {
  	$error_message .= '<b style="font-size:12px; color:red; font-family:calibri;">The First Name you entered does not appear to be valid.</b><br />';
  }
  if(!preg_match($string_exp,$subject)) {
  	$error_message .= '<b style="font-size:12px; color:black; font-family:calibri;">The Last Name you entered does not appear to be valid.</b><br />';
  }
  if(strlen($message) < 2) {
  	$error_message .= '<b style="font-size:12px; color:red; font-family:calibri;">The Message that you entered do not appear to be valid.</b><br />';
  }
  if(strlen($error_message) > 0) {
  	died($error_message);
  }
	$email_message = "Contact Form details below...\n\n\n";
	
	function clean_string($string) {
	  $bad = array("content-type","bcc:","to:","cc:","href");
	  return str_replace($bad,"",$string);
	}
	
	$email_message .= "Name: ".clean_string($name)."\n\n";
	$email_message .= "Email: ".clean_string($email)."\n\n";
	$email_message .= "Contact No.: ".clean_string($phone)."\n\n";
	$email_message .= "Company: ".clean_string($company)."\n\n";
	$email_message .= "Subject: ".clean_string($subject)."\n\n";
	$email_message .= "Message/Comments: ".clean_string($message)."\n\n\n";
	
	
// create email headers
$headers = 'From: '.$email."\r\n".
'Reply-To: '.$email."\r\n" .
'X-Mailer: PHP/' . phpversion();
@mail($email_to, $email_subject, $email_message, $headers);  
?>

<!-- place your own success html below -->

<!--<h2>Thanks for contacting us!</h2>-->

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    
    
    <link rel="shortcut icon" href="img/icon.ico">
    <link rel="Stylesheet" href="css/style.css" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500&display=swap" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css2?family=Bad+Script&family=Great+Vibes&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Merriweather+Sans:400,700" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,300italic,400italic,700,700italic' rel='stylesheet' type='text/css'>

    <script src="https://kit.fontawesome.com/3d0a07deaa.js" crossorigin="anonymous"></script>

    <title>Microsoft HPC Azure | Thank You</title>
    
  </head>
  <body>
    <div id="wrapper">
    <header>   
      <a href="index.html"><div class="logo"></a>
       <a href="#"> <span>Microsoft</span> HPC Azure</a><br>
          <span>
          <a href="#">
            <img src="img/MicrosoftLogo_Small.png" alt="Microsoft Logo" />
          </a>
        </span> 
        <span>
          <a href="#">
            <img src="img/CapgeminiLogo_Small.png" alt="Capgemini Logo" />
          </a>
        </span>

      </div>

    </header>

    
    <main>

    <section id="error" class="container text-center contact-success py-5">
        <h1>Message Sent Sucessfully!</h1>
        <p>Thank you for Contacting Us...</p>
        <a class="btn btn-primary" href="index.shtml">GO BACK TO THE HOMEPAGE</a>
    </section><!--/#error-->


    </main>

    <footer>
        <div class="d-flex justify-content-around align-items-center">
          <p class="pt-md-3">&copy; 2021 Microsoft HPC Azure</p>
          <ul>
            <li>
              <a href="#">
                <img src="img/CapgeminiLogo.png" alt="Capgemini Logo" />
              </a>
            </li>
            <li>
              <a href="#">
                <img src="img/MicrosoftLogo.png" alt="Microsoft Logo" />
              </a>
            </li>
          </ul>
        </div>
      </footer>

      </div><!--wrapper-->
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->

  </body>
</html>


<?php
}
die();
?>